export const COLOR_PINK = '#164977'
export const COLOR_PINK_LIGHT = '#164977'
export const COLOR_FACEBOOK = '#3b5998'
export const COLOR_PINK_MEDIUM = 'rgb(255,119,34)'